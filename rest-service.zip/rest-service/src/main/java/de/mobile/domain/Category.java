package de.mobile.domain;

public enum Category {
    Car, Motorbike, Truck
}

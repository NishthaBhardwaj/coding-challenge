insert into mobile_customer(id,first_name,last_name,company_name,email)
values(2001, 'Nishtha','Bhardwaj','JPMC','nishtha@gmail.com');


insert into mobile_ad(id,make,model,description,category,price)
values(3001,'Iphone','12','IPhone 5G','Car',45.35);

insert into mobile_ad_customer(ad_id,customer_id)
values(3001,2001);

